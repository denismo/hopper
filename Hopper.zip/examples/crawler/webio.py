__author__ = 'Denis Mikhalkin'

def download(url):
    if url == 'http://abc.com':
        return """
            https://github.com/denismo/DynamoFS/blob/master/dynamofuse/fs.py
            http://www.nswschoolholiday.com.au/index.php/nsw-school-holiday-dates-2016
            https://au-mg6.mail.yahoo.com/neo/launch
            http://www.bom.gov.au/jsp/ncc/cdio/weatherData/av
            http://livefootballvideo.com/fullmatch/europe/wc-qualification-europe/spain-vs-liechtenstein
        """