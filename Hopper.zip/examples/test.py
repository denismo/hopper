from __future__ import print_function

def lambda_handler(event, lambda_context):
    print('Lambda is working')