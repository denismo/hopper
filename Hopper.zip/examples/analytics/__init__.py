__author__ = 'Denis Mikhalkin'

def lookupUserAgent(userAgent):
    return dict(deviceType='desktop', browser='chrome')

def incrementUserCounter(cookie, country):
    pass

def incrementPageView(path, country):
    pass

def parsePath(url):
    return ""
